package LinkedIn_Clone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LinkedInCloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
