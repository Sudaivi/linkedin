package LinkedIn_Clone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
public class LinkedInCloneApplication {

	public static void main(String[] args) {
		SpringApplication.run(LinkedInCloneApplication.class, args);
	}

}
