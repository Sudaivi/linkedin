package LinkedIn_Clone.response;

import lombok.Data;

@Data
public class ApiRespones {


	 private final boolean success;
	    private final Object data;
	    private final String message;

	    public ApiRespones(boolean success, Object data, String message) {
	        this.success = success;
	        this.data = data;
	        this.message = message;
	    }

	   
}

