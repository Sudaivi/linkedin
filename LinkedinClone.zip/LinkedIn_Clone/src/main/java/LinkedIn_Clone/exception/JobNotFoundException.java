package LinkedIn_Clone.exception;

public class JobNotFoundException extends Exception{
	public JobNotFoundException(String message) {
        super(message);
    }

}
