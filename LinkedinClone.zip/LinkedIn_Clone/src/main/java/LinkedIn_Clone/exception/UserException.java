package LinkedIn_Clone.exception;

public class UserException extends Exception{
	
	public UserException(String massage) {
		super(massage);
	}

}
