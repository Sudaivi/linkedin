package LinkedIn_Clone.exception;

public class DuplicateUserException extends RuntimeException {

	public DuplicateUserException(String message) {
        super(message);
    }
	
	@Override
    public String getMessage() {
        return super.getMessage();
    }
}
