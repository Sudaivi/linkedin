package LinkedIn_Clone.exception;

public class PostException extends Exception{
	
	public PostException(String massage) {
		super(massage);
	}

}
