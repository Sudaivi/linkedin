package LinkedIn_Clone.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.entites.SignUp;
import LinkedIn_Clone.repositories.SignUpRepository;
import LinkedIn_Clone.service.SignUpService;

@Service
public class SignUpServiceImpl implements SignUpService{
	
	@Autowired
	 private SignUpRepository signUpRepository;

	@Override
	public SignUp registerUser(SignUp signup) {
		
		return signUpRepository.save(signup);
	}

	@Override
	public SignUp findByEmail(String email) {
		
		return signUpRepository.findByEmail(email);
	}

}
