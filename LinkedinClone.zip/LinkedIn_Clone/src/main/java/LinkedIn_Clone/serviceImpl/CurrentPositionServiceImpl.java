package LinkedIn_Clone.serviceImpl;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.dto.CurrentPositionDto;
import LinkedIn_Clone.entites.WorkExprience;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.repositories.CurrentPositionRepository;
import LinkedIn_Clone.repositories.UserRepository;
import LinkedIn_Clone.service.CurrentPositionService;

@Service
public class CurrentPositionServiceImpl implements CurrentPositionService {

	
	 	@Autowired
	    private CurrentPositionRepository currentPositionRepository;
	 
	 	@Autowired
		private UserRepository userRepository;

	    @Autowired
	    private ModelMapper modelMapper;

	    
	    @Override
	    public CurrentPositionDto addCurrentPosition(CurrentPositionDto currentPositionDto) {
	        WorkExprience currentPosition = dtoToEntity(currentPositionDto);
	        
	        User user = userRepository.findById(currentPositionDto.getUserId())
	                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", currentPositionDto.getUserId()));

	        currentPosition.setUser(user);
	        
	        WorkExprience savedCurrentPosition = currentPositionRepository.save(currentPosition);
	        return entityToDto(savedCurrentPosition);
	    }
	    
	    

	    @Override
	    public CurrentPositionDto updateCurrentPosition(CurrentPositionDto currentPositionDto, Long currentPositionId) {
	        WorkExprience currentPosition = currentPositionRepository.findById(currentPositionId)
	                .orElseThrow(() -> new ResourceNotFoundException("CurrentPosition", "Id", currentPositionId));

	        // Update currentPosition with new values
	        currentPosition.setTitle(currentPositionDto.getTitle());
	        currentPosition.setEmploymentType(currentPositionDto.getEmploymentType());
	        currentPosition.setCompanyName(currentPositionDto.getCompanyName());
	        currentPosition.setLocation(currentPositionDto.getLocation());
	        currentPosition.setLocationType(currentPositionDto.getLocationType());
	        currentPosition.setStartDate(currentPositionDto.getStartDate());
	        currentPosition.setEndDate(currentPositionDto.getEndDate());
	        currentPosition.setDescription(currentPositionDto.getDescription());
	        currentPosition.setSkills(currentPositionDto.getSkills());
	        
	        
	        // Set the user again 
	        User user = userRepository.findById(currentPositionDto.getUserId())
	                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", currentPositionDto.getUserId()));

	        currentPosition.setUser(user);

	        WorkExprience updatedCurrentPosition = currentPositionRepository.save(currentPosition);
	        return entityToDto(updatedCurrentPosition);
	    }

	    @Override
	    public void deleteCurrentPosition(Long currentPositionId) {
	        WorkExprience currentPosition = currentPositionRepository.findById(currentPositionId)
	                .orElseThrow(() -> new ResourceNotFoundException("CurrentPosition", "Id", currentPositionId));

	    
	        currentPositionRepository.delete(currentPosition);
	    }

	    @Override
	    public CurrentPositionDto getCurrentPositionById(Long currentPositionId) {
	        WorkExprience currentPosition = currentPositionRepository.findById(currentPositionId)
	                .orElseThrow(() -> new ResourceNotFoundException("CurrentPosition", "Id", currentPositionId));
	        return entityToDto(currentPosition);
	    }

	    private WorkExprience dtoToEntity(CurrentPositionDto currentPositionDto) {
	        return modelMapper.map(currentPositionDto, WorkExprience.class);
	    }

	    private CurrentPositionDto entityToDto(WorkExprience currentPosition) {
	        return modelMapper.map(currentPosition, CurrentPositionDto.class);
	    }
	}

