package LinkedIn_Clone.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import LinkedIn_Clone.entites.Job;
import LinkedIn_Clone.exception.JobNotFoundException;
import LinkedIn_Clone.repositories.JobRepository;
import LinkedIn_Clone.service.JobService;



@Service
public class JobServiceImpl implements JobService {

	    @Autowired
	    private JobRepository jobRepository;

	    public Job createJob(Job job) {
	        return jobRepository.save(job);
	    }

	    public List<Job> getAllJobs() {
	        return jobRepository.findAll();
	    }

	    public List<Job> searchJobs(String location, String industry) {
	        if (location == null && industry == null) {
	            return getAllJobs();
	        } else if (location != null && industry == null) {
	            return jobRepository.findByLocation(location);
	        } else if (location == null && industry != null) {
	            return jobRepository.findByIndustry(industry);
	        } else {
	            return jobRepository.findByLocationAndIndustry(location, industry);
	        }
	    }
	    public Job getJobDetails(Long jobId) throws JobNotFoundException{
	       Job job = jobRepository.findById(jobId).orElseThrow(()-> new JobNotFoundException("Job not found"+jobId));
	       return job;
	    } 
	
	    
	    public Job updateJob(Long jobId, Job updatedJob) throws JobNotFoundException {
	        Job existingJob = jobRepository.findById(jobId).orElse(null);

	        if (existingJob != null) {
	            existingJob.setTitle(updatedJob.getTitle());
	            existingJob.setDescription(updatedJob.getDescription());
	            existingJob.setLocation(updatedJob.getLocation());
	            existingJob.setIndustry(updatedJob.getIndustry());

	            return jobRepository.save(existingJob);
	            
	        } else {
	        	throw new JobNotFoundException("Job not found with Id");
	            
	        }
	        
	    }
	    
	    public List<Job> getSavedJobs() {
	        return jobRepository.findByIsSaved(true);
	    }

	
}
	
	
	
	
	
	

