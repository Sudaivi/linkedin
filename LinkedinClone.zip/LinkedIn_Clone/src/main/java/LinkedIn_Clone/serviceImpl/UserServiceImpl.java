package LinkedIn_Clone.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.dto.CurrentPositionDto;
import LinkedIn_Clone.dto.EducationDto;
import LinkedIn_Clone.dto.UserDto;

import LinkedIn_Clone.entites.WorkExprience;
import LinkedIn_Clone.entites.Education;
import LinkedIn_Clone.entites.User;

import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.repositories.UserRepository;

import LinkedIn_Clone.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public UserDto createUser (UserDto userdto) {
		
		User user = this.dtoToUser(userdto);
		User saveUser = this.userRepository.save(user);
		return this.userToDto(saveUser);
		
	}

	@Override
	public UserDto updateUser(UserDto userDto, Long userId) {
		
		User user = this.userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User","Id",userId));
		user.setFirstName(userDto.getFirstName());
		user.setLastName(userDto.getLastName());
		user.setEmail(userDto.getEmail());
		user.setPassword(userDto.getPassword());
		user.setDateOfBirth(userDto.getDateOfBirth());
		user.setLocation(userDto.getLocation());
		user.setImage(userDto.getImage());
		user.setMobile(userDto.getMobile());
		user.setBackGroundImage(userDto.getBackGroundImage());
		user.setHeadline(userDto.getHeadline());
		user.setAbout(userDto.getAbout());
		user.setSkills(userDto.getSkills());
		User updateUser= userRepository.save(user);
		
		 UserDto userToDto1= this.userToDto(updateUser);
		 return userToDto1;
	}

	@Override
	public UserDto getUserById(Long userId) {
		User user = this.userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User","Id",userId));
		return this.userToDto(user);
	}

	@Override
	public void deleteUser(Long userId) {
		User user = this.userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User","Id",userId));
		this.userRepository.delete(user);
	}

	@Override
	public List<UserDto> getAllUser() {
		List<User> users = this.userRepository.findAll();
		List<UserDto> userdtos = users.stream().map(user->this.userToDto(user)).collect(Collectors.toList());
		return userdtos;
	}


	@Override
	public User followUser(User user, Long userId) {
		User followToUser = this.userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User","Id",userId));
		
		if(user.getFollowing().contains(followToUser)&& followToUser.getFollowers().contains(user)) {
			user.getFollowing().remove(followToUser);
			followToUser.getFollowers().remove(user);
		}
		else {
			user.getFollowing().add(followToUser);
			followToUser.getFollowers().add(user);
		}
		
		userRepository.save(followToUser);
		userRepository.save(user);
		return followToUser;
	}
	
	@Override
    public List<EducationDto> getUserEducations(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));
        List<Education> educations = user.getEducations();
        return educations.stream().map(this::educationToDto).collect(Collectors.toList());
    }

   
    @Override
    public List<CurrentPositionDto> getUserCurrentPositions(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));
        List<WorkExprience> currentPositions = user.getCurrentPosition();
        return currentPositions.stream().map(this::currentPositionToDto).collect(Collectors.toList());
    }
	
	
	//converting userDto To User
	
	public User dtoToUser(UserDto userDto) {
		User user = this.modelMapper.map(userDto, User.class);
		return user;
	}
	
	
	//converting user To UserDto
	public UserDto userToDto (User user) {
		UserDto userDto = this.modelMapper.map(user, UserDto.class);
		return userDto;
	}
	
	public static List<UserDto> userToDtos (List<User> followers){
		List <UserDto> userDtos = new ArrayList<>();
		
		for(User user : followers) {
			UserDto userDto = new UserDto();
			userDto.setId(user.getId());
			userDto.setEmail(user.getEmail());
			userDto.setFirstName(user.getFirstName());
			userDto.setImage(user.getImage());
			userDtos.add(userDto);	
			
		}
		
		return userDtos;
	}

	private EducationDto educationToDto(Education education) {
        return modelMapper.map(education, EducationDto.class);
    }

	
    private CurrentPositionDto currentPositionToDto(WorkExprience currentPosition) {
        return modelMapper.map(currentPosition, CurrentPositionDto.class);
    }


	


	

}
