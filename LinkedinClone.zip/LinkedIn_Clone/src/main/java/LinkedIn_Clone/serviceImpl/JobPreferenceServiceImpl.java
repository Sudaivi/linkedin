package LinkedIn_Clone.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.entites.Job;
import LinkedIn_Clone.entites.JobPreference;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.repositories.JobPreferenceRepository;
import LinkedIn_Clone.repositories.JobRepository;
import LinkedIn_Clone.repositories.UserRepository;
import LinkedIn_Clone.service.JobPreferenceService;

@Service
public class JobPreferenceServiceImpl implements JobPreferenceService {

	
	    @Autowired
	    private JobPreferenceRepository jobPreferenceRepository;

	    @Autowired
	    private JobRepository jobRepository;

	    @Autowired
	    private UserRepository userRepository;

	    public JobPreference createJobPreference(Long userId, Long jobId, JobPreference jobPreference) {
	        User user = userRepository.findById(userId)
	                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));

	        Job job = jobRepository.findById(jobId)
	                .orElseThrow(() -> new ResourceNotFoundException("Job", "Id", jobId));

	        jobPreference.setUser(user);
	        jobPreference.setJob(job);


	        return jobPreferenceRepository.save(jobPreference);
	    }

	    public List<JobPreference> getJobPreferencesForUser(Long userId) {
	        return jobPreferenceRepository.findByUserId(userId);
	    }

	    public List<JobPreference> getJobPreferencesForJob(Long jobId) {
	        return jobPreferenceRepository.findByJobId(jobId);
	    }

	    public void deleteJobPreference(Long jobPreferenceId) {
	        jobPreferenceRepository.deleteById(jobPreferenceId);
	    }
	}





