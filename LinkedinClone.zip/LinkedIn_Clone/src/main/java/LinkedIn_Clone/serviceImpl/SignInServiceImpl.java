package LinkedIn_Clone.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.entites.SignIn;
import LinkedIn_Clone.repositories.SignInRepository;
import LinkedIn_Clone.service.SignInService;




@Service
public class SignInServiceImpl implements SignInService {
	
	@Autowired
	private SignInRepository signInRepository;

	@Override
	public SignIn registerUser(SignIn signIn) {
		
		return signInRepository.save(signIn);
	}

	@Override
	public SignIn findByEmail(String email) {
		
		return signInRepository.findByEmail(email);
	}
	
	  @Override
	    public void updatePassword(SignIn signIn, String newPassword) {
	        signIn.setPassword(newPassword);
	        signInRepository.save(signIn);
	    }
	

}
