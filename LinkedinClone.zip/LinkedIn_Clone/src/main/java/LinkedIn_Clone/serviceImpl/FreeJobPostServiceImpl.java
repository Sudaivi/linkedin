package LinkedIn_Clone.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.entites.FreeJobPost;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.repositories.FreeJobPostRepository;
import LinkedIn_Clone.service.FreeJobPostService;

@Service
public class FreeJobPostServiceImpl implements FreeJobPostService {

	 @Autowired
	    private FreeJobPostRepository freeJobPostRepository;

	    public FreeJobPost postFreeJob(FreeJobPost freeJobPost) {
	      
	        return freeJobPostRepository.save(freeJobPost);
	    }

	    public List<FreeJobPost> getAllFreeJobPosts() {
	        return freeJobPostRepository.findAll();
	    }

	    public FreeJobPost getFreeJobPostById(Long freeJobPostId) {
	        return freeJobPostRepository.findById(freeJobPostId)
	                .orElseThrow(() -> new ResourceNotFoundException("FreeJobPost", "Id", freeJobPostId));
	    }

	    public void deleteFreeJobPost(Long freeJobPostId) {
	        freeJobPostRepository.deleteById(freeJobPostId);
	    }
	}
