package LinkedIn_Clone.serviceImpl;

import java.util.List;

import org.omg.CORBA.UserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.entites.Like;
import LinkedIn_Clone.entites.Post;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.PostException;
import LinkedIn_Clone.repositories.LikeRepository;
import LinkedIn_Clone.repositories.PostRepository;
import LinkedIn_Clone.service.LikeService;
import LinkedIn_Clone.service.PostServices;


@Service
public class LikeServiceImpl implements LikeService {
	
	@Autowired
	private LikeRepository likeRepository;
	
	@Autowired
	private PostRepository postRepository;
	
	@Autowired
	private PostServices postServices;

	
	
	@Override
	public Like likePost(Long postId, User user) throws PostException, UserException {
		Like isLikeExist = likeRepository.isLikeExist(user.getId(), postId);
		
		if(isLikeExist != null) {
			likeRepository.deleteById(isLikeExist.getId());
			return isLikeExist;
		}
		Post post = postServices.findPostById(postId);
		
		Like like = new Like();
		like.setPost(post);
		like.setUser(user);
		
		Like savedLike= likeRepository.save(like);
		
		post.getLike().add(savedLike);
		postRepository.save(post);
		
		return savedLike;
	}

	@Override
	public List<Like> getAllLikes(Long postId) throws PostException {
		Post post = postServices.findPostById(postId);
		List <Like> likes = likeRepository.findByPostId(postId);
		return likes;
	}



}
