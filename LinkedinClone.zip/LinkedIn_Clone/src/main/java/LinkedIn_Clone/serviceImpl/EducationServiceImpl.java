package LinkedIn_Clone.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



import LinkedIn_Clone.dto.EducationDto;
import LinkedIn_Clone.entites.Education;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.repositories.EducationRepository;
import LinkedIn_Clone.repositories.UserRepository;
import LinkedIn_Clone.service.EducationService;

@Service
public class EducationServiceImpl implements EducationService{

	
	@Autowired
    private EducationRepository educationRepository;
	
	@Autowired
	private UserRepository userRepository;

    @Autowired
    private ModelMapper modelMapper;

    @Override
    public EducationDto createEducation(EducationDto educationDto) {
        Education education = dtoToEducation(educationDto);

        //  get the user based on the userId
        User user = userRepository.findById(educationDto.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", educationDto.getUserId()));

        education.setUser(user);

        Education savedEducation = educationRepository.save(education);
        return educationToDto(savedEducation);
    }

    @Override
    public EducationDto updateEducation(EducationDto educationDto, Long educationId) {
        Education education = educationRepository.findById(educationId)
                .orElseThrow(() -> new ResourceNotFoundException("Education", "Id", educationId));

        education.setDegree(educationDto.getDegree());
        education.setSchool(educationDto.getSchool());
        education.setStartDate(educationDto.getStartDate());
        education.setEndDate(educationDto.getEndDate());
        
        // Set the user again in case it's being updated
        User user = userRepository.findById(educationDto.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User", "Id", educationDto.getUserId()));

        education.setUser(user);

        Education updatedEducation = educationRepository.save(education);
        return educationToDto(updatedEducation);
    }

    @Override
    public EducationDto getEducationById(Long educationId) {
        Education education = educationRepository.findById(educationId)
                .orElseThrow(() -> new ResourceNotFoundException("Education", "Id", educationId));
        return educationToDto(education);
    }

    @Override
    public void deleteEducation(Long educationId) {
        Education education = educationRepository.findById(educationId)
                .orElseThrow(() -> new ResourceNotFoundException("Education", "Id", educationId));
        educationRepository.delete(education);
    }

    @Override
    public List<EducationDto> getAllEducation() {
        List<Education> educations = educationRepository.findAll();
        List<EducationDto> educationDto = educations.stream().map(education->this.educationToDto(education)).collect(Collectors.toList());
    	return educationDto;
        
    }
    
    

    private Education dtoToEducation(EducationDto educationDto) {
        return modelMapper.map(educationDto, Education.class);
    }

    private EducationDto educationToDto(Education education) {
        return modelMapper.map(education, EducationDto.class);
    }
}
