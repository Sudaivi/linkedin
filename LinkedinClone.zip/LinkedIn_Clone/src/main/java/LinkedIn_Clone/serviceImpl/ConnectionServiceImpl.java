package LinkedIn_Clone.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import LinkedIn_Clone.entites.Connection;
import LinkedIn_Clone.entites.ConnectionStatus;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.repositories.ConnectionRepository;
import LinkedIn_Clone.service.ConnectionService;

@Service
public class ConnectionServiceImpl implements ConnectionService{

	
	 	@Autowired
	    private ConnectionRepository connectionRepository;

	    @Override
	    public List<Connection> getPendingConnections(User receiver) {
	        return connectionRepository.findByReceiverAndStatus(receiver, ConnectionStatus.PENDING);
	    }

	    @Override
	    public void acceptConnection(Long connectionId) {
	        Connection connection = connectionRepository.findById(connectionId)
	                .orElseThrow(() -> new RuntimeException("Connection not found"));

	        connection.setStatus(ConnectionStatus.ACCEPTED);
	        connectionRepository.save(connection);
	    }

	    @Override
	    public void rejectConnection(Long connectionId) {
	        Connection connection = connectionRepository.findById(connectionId)
	                .orElseThrow(() -> new RuntimeException("Connection not found"));

	        connection.setStatus(ConnectionStatus.REJECTED);
	        connectionRepository.save(connection);
	    }

	    @Override
	    public Connection sendConnectionRequest(User sender, User receiver) {
	        Connection connection = new Connection();
	        connection.setSender(sender);
	        connection.setReceiver(receiver);
	        connection.setStatus(ConnectionStatus.PENDING);

	        return connectionRepository.save(connection);
	    }
	    
	    @Override
	    public void removeConnection(Long connectionId) {
	        connectionRepository.deleteById(connectionId);
	    }
	    
	    @Override
	    public List<Connection> getAllConnectedConnections(User user) {
	        return connectionRepository.findBySenderAndStatusOrReceiverAndStatus(user, ConnectionStatus.ACCEPTED, user, ConnectionStatus.ACCEPTED);
	    }
	}