package LinkedIn_Clone.serviceImpl;

import java.time.LocalDateTime;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.omg.CORBA.UserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import LinkedIn_Clone.dto.PostDto;
import LinkedIn_Clone.entites.Post;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.PostException;
import LinkedIn_Clone.repositories.PostRepository;
import LinkedIn_Clone.request.PostReplyRequest;
import LinkedIn_Clone.service.PostServices;


@Service
public class PostServiceImpl implements PostServices {

	@Autowired
	private PostRepository postRepository;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public Post createPost(Post req,User user) throws UserException {
		
		Post post = new Post();
		
		post.setComment(req.getComment());
		post.setCreatedAt(LocalDateTime.now());
		post.setImage(req.getImage());
		post.setVideo(req.getVideo());
		post.setUser(user);
		post.setReply(false);
		post.setPost(true);
		return postRepository.save(post);
	}

	@Override
	public List<Post> findAllPost() {
		return postRepository.findAllByIsPostOrderByCreatedAtDesc(true);
	}

	@Override
	public Post findPostById(Long postId) throws PostException {
		Post post = postRepository.findById(postId).orElseThrow(()-> new PostException("Post not found"+postId));
		return post;
	}

	
	
	@Override
	public void deletPostById(Long postId, Long userId) throws PostException, UserException {
	    try {
	        Post post = findPostById(postId);

	        if (post == null) {
	            throw new PostException("Post not found with id: " + postId);
	        }

	        if (!userId.equals(post.getUser().getId())) {
	            throw new PostException("You can't delete others Post");
	        }

	        postRepository.deleteById(post.getId());
	    } catch (Exception e) {
	        
	        throw new PostException("Error deleting post: " + e.getMessage());
	    }
	}
	

	@Override
	public Post createReply(PostReplyRequest req, User user) throws PostException {

		Post replyFor = findPostById(req.getPostId());
		
		Post post = new Post();
		
		post.setComment(req.getContent());
		post.setCreatedAt(LocalDateTime.now());
		post.setImage(req.getImage());
		post.setVideo(req.getVideo());
		post.setUser(user);
		post.setReply(true);
		post.setPost(false);
		post.setReplyFor(replyFor);
		Post savedReply = postRepository.save(post);
		post.getReplyPost().add(savedReply);
		postRepository.save(replyFor);
		return replyFor;
		
	}

	
	@Override
	public List<Post> getUserPost(User user) {
		
		
		return postRepository.findByUserAndIsPostOrderByCreatedAtDesc(user, true);
	}

	@Override
	public List<Post> findByLikesContainUser(User user) {
		
		return postRepository.findByLikesUserId(user.getId());
	}
	
	
	
	
	// converting userdto to user
	
	public Post dtoToPost(PostDto postDto) {
		Post post = this.modelMapper.map(postDto, Post.class);
		return post;
	}
	
	
	//converting user to userdto
	
	public PostDto postToDto (Post post) {
		PostDto postDto = this.modelMapper.map(post, PostDto.class);
		return postDto;
	}
	

}








