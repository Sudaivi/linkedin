package LinkedIn_Clone.request;

import java.time.LocalDateTime;

import lombok.Data;

@Data
public class PostReplyRequest {

	private String content;
	private Long postId;
	private LocalDateTime createdBy;
	private String image;
	private String video;
	
}
