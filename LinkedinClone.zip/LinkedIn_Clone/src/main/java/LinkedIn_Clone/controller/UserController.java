package LinkedIn_Clone.controller;



import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import LinkedIn_Clone.dto.UserDto;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.DuplicateUserException;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.response.ApiResponse;
import LinkedIn_Clone.serviceImpl.UserServiceImpl;


@RestController
@RequestMapping("/api/users")
public class UserController {
	
	@Autowired
	private UserServiceImpl userServiceImpl;
	
	@PostMapping("/user")
	public ResponseEntity<?> createUser(@RequestBody UserDto userdto){
		  try {
		        UserDto createdUserDto = userServiceImpl.createUser(userdto);
		        return new ResponseEntity<>(createdUserDto, HttpStatus.CREATED);
		    } catch (DuplicateUserException e) {
		        ApiResponse errorResponse = new ApiResponse(e.getMessage(), false);
		        return new ResponseEntity<>(errorResponse, HttpStatus.CONFLICT);
		    }
	}
	
	@PutMapping("/user/{userId}")
	public ResponseEntity<UserDto>  updateUser(@RequestBody UserDto userdto,@PathVariable Long userId){
		UserDto updateUserDto = this.userServiceImpl.updateUser(userdto,userId);
		return new ResponseEntity<>(updateUserDto,HttpStatus.OK);
	}
	
	@DeleteMapping("{userId}")
	public ResponseEntity <?>  deleteUser(@PathVariable Long userId){
		  this.userServiceImpl.deleteUser(userId);
		return new ResponseEntity<>(HttpStatus.OK);
	}
	
	@GetMapping("/user")
	public List<UserDto> getAllUser(){
		return this.userServiceImpl.getAllUser();
		
	}

	@GetMapping("{userId}")
	public ResponseEntity <UserDto>  getUserById(@PathVariable Long userId){
		UserDto getUserById = this.userServiceImpl.getUserById(userId);
		return new ResponseEntity<>(getUserById,HttpStatus.OK);
	}
	
	 @PostMapping("/follow/{userId}")
	    public ResponseEntity<User> followUser(@RequestBody User user, @PathVariable Long userId) {
	        try {
	            User followedUser = userServiceImpl.followUser(user, userId);
	            return new ResponseEntity<>(followedUser, HttpStatus.OK);
	        } catch (ResourceNotFoundException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	 }

}
