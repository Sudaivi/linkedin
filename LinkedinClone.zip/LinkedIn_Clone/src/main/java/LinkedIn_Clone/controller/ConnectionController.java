package LinkedIn_Clone.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import LinkedIn_Clone.entites.Connection;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.repositories.UserRepository;
import LinkedIn_Clone.serviceImpl.ConnectionServiceImpl;

@RestController
@RequestMapping("/api/connections")
public class ConnectionController {


	    @Autowired
	    private ConnectionServiceImpl connectionService;
	    
	    @Autowired
		private UserRepository userRepository;

	    @GetMapping("/pending")
	    public List<Connection> getPendingConnections(@RequestParam Long userId) {
	        User receiver = this.userRepository.findById(userId).orElseThrow(()-> new ResourceNotFoundException("User","Id",userId));         
	        return connectionService.getPendingConnections(receiver);
	    }

	    @PostMapping("/accept")
	    public ResponseEntity<String> acceptConnection(@RequestParam Long connectionId) {
	        try {
	            connectionService.acceptConnection(connectionId);
	            return new ResponseEntity<>("Connection accepted successfully", HttpStatus.OK);
	        } catch (RuntimeException e) {
	            return new ResponseEntity<>("Connection not found", HttpStatus.NOT_FOUND);
	        }
	    }

	    @PostMapping("/reject")
	    public ResponseEntity<String> rejectConnection(@RequestParam Long connectionId) {
	        try {
	            connectionService.rejectConnection(connectionId);
	            return new ResponseEntity<>("Connection rejected successfully", HttpStatus.OK);
	        } catch (RuntimeException e) {
	            return new ResponseEntity<>("Connection not found", HttpStatus.NOT_FOUND);
	        }
	    }

	    @PostMapping("/request")
	    public ResponseEntity<?> sendConnectionRequest( @RequestParam Long senderId, @RequestParam Long receiverId) {
	        try {
	            Optional<User> optionalSender = userRepository.findById(senderId);
	            Optional<User> optionalReceiver = userRepository.findById(receiverId);

	            if (optionalSender.isPresent() && optionalReceiver.isPresent()) {
	                User sender = optionalSender.get();
	                User receiver = optionalReceiver.get();

	                Connection createdConnection = connectionService.sendConnectionRequest(sender, receiver);
	                return new ResponseEntity<>(createdConnection, HttpStatus.CREATED);
	            } else {
	                return new ResponseEntity<>("Sender or receiver not found", HttpStatus.NOT_FOUND);
	            }
	        } catch (RuntimeException e) {
	            return new ResponseEntity<>("Internal server error", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }

	    @DeleteMapping("/remove-connection/{connectionId}")
	    public ResponseEntity<Void> removeConnection(@PathVariable Long connectionId) {
	        connectionService.removeConnection(connectionId);
	        return new ResponseEntity<>(HttpStatus.OK);
	    }
	    
	    @GetMapping("/connected")
	    public ResponseEntity<?> getAllConnectedConnections(@RequestParam Long userId) {
	        try {
	            User user = userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("User", "Id", userId));
	            List<Connection> connectedConnections = connectionService.getAllConnectedConnections(user);

	            if (connectedConnections.isEmpty()) {
	                return new ResponseEntity<>("No connected connections found", HttpStatus.NOT_FOUND);
	            } else {
	                return new ResponseEntity<>(connectedConnections, HttpStatus.OK);
	            }
	        } catch (ResourceNotFoundException e) {
	            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	        } catch (Exception e) {
	            return new ResponseEntity<>("Internal server error", HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }

	}