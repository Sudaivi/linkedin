package LinkedIn_Clone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import LinkedIn_Clone.entites.JobPreference;
import LinkedIn_Clone.service.JobPreferenceService;


@RestController
@RequestMapping("/api/job")
public class JobPreferenceController {

	@Autowired
    private JobPreferenceService jobPreferenceService;

    @PostMapping("/{userId}/{jobId}")
    public ResponseEntity<JobPreference> createJobPreference(
            @PathVariable Long userId,
            @PathVariable Long jobId,
            @RequestBody JobPreference jobPreference) {
        JobPreference createdJobPreference = jobPreferenceService.createJobPreference(userId, jobId, jobPreference);
        return new ResponseEntity<>(createdJobPreference, HttpStatus.CREATED);
    }

    @GetMapping("/user/{userId}")
    public ResponseEntity<List<JobPreference>> getJobPreferencesForUser(@PathVariable Long userId) {
        List<JobPreference> jobPreferences = jobPreferenceService.getJobPreferencesForUser(userId);
        return new ResponseEntity<>(jobPreferences, HttpStatus.OK);
    }

    @GetMapping("/job/{jobId}")
    public ResponseEntity<List<JobPreference>> getJobPreferencesForJob(@PathVariable Long jobId) {
        List<JobPreference> jobPreferences = jobPreferenceService.getJobPreferencesForJob(jobId);
        return new ResponseEntity<>(jobPreferences, HttpStatus.OK);
    }

    @DeleteMapping("/{jobPreferenceId}")
    public ResponseEntity<Void> deleteJobPreference(@PathVariable Long jobPreferenceId) {
        jobPreferenceService.deleteJobPreference(jobPreferenceId);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}

