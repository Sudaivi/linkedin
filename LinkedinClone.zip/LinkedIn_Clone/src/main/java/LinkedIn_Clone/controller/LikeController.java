package LinkedIn_Clone.controller;

import java.util.List;

import org.omg.CORBA.UserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import LinkedIn_Clone.dto.LikeDto;
import LinkedIn_Clone.entites.Like;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.PostException;
import LinkedIn_Clone.mapper.LikeDtoMapper;
import LinkedIn_Clone.repositories.UserRepository;
import LinkedIn_Clone.serviceImpl.LikeServiceImpl;


@RestController
@RequestMapping("/api/likes")
public class LikeController {
	
	@Autowired
	private LikeServiceImpl likeServiceImpl;
	
	@Autowired
	private UserRepository userRepository;

	

	@PostMapping("/likes/{postId}")
    public ResponseEntity<LikeDto> createPost(@PathVariable Long postId, String email)throws PostException, UserException{
		User user = userRepository.findByEmail(email);
		Like like = likeServiceImpl.likePost(postId, user);
		LikeDto likeDto = LikeDtoMapper.toLikeDto(like, user);
		return new ResponseEntity<>(likeDto,HttpStatus.CREATED);
    }
	

	@PostMapping("/post/{postId}")
    public ResponseEntity<List<LikeDto>> getAllLikes(@PathVariable Long postId, String email)throws PostException, UserException{
		User user = userRepository.findByEmail(email);
		List <Like> like = likeServiceImpl.getAllLikes(postId);
		List <LikeDto> likeDtos = LikeDtoMapper.toLikeDtos(like, user);
		return new ResponseEntity<>(likeDtos,HttpStatus.CREATED);
    }
	

}
