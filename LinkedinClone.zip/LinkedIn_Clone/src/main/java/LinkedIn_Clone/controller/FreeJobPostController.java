package LinkedIn_Clone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import LinkedIn_Clone.entites.FreeJobPost;
import LinkedIn_Clone.service.FreeJobPostService;

@RestController
@RequestMapping("/api/job")
public class FreeJobPostController {
	
	 @Autowired
	    private FreeJobPostService freeJobPostService;

	    @PostMapping
	    public ResponseEntity<FreeJobPost> postFreeJob(@RequestBody FreeJobPost freeJobPost) {
	        FreeJobPost createdFreeJobPost = freeJobPostService.postFreeJob(freeJobPost);
	        return new ResponseEntity<>(createdFreeJobPost, HttpStatus.CREATED);
	    }

	    @GetMapping
	    public ResponseEntity<List<FreeJobPost>> getAllFreeJobPosts() {
	        List<FreeJobPost> freeJobPosts = freeJobPostService.getAllFreeJobPosts();
	        return new ResponseEntity<>(freeJobPosts, HttpStatus.OK);
	    }

	    @GetMapping("/{freeJobPostId}")
	    public ResponseEntity<FreeJobPost> getFreeJobPostById(@PathVariable Long freeJobPostId) {
	        FreeJobPost freeJobPost = freeJobPostService.getFreeJobPostById(freeJobPostId);
	        return new ResponseEntity<>(freeJobPost, HttpStatus.OK);
	    }

	    @DeleteMapping("/{freeJobPostId}")
	    public ResponseEntity<Void> deleteFreeJobPost(@PathVariable Long freeJobPostId) {
	        freeJobPostService.deleteFreeJobPost(freeJobPostId);
	        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
	    }

}
