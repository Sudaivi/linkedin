package LinkedIn_Clone.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import LinkedIn_Clone.entites.SignIn;
import LinkedIn_Clone.serviceImpl.SignInServiceImpl;


@RestController
@RequestMapping("/api")
public class SignInController {
	
	@Autowired
	 private SignInServiceImpl signInServiceImpl;
	
	   
	
	@PostMapping("/signin")
    public ResponseEntity<String> login(@RequestBody SignIn signIn, HttpSession session) {
		
		  if (signIn.getEmail() != null && signIn.getPassword() != null) {
			  
		        // Retrieve the user from the database based on the provided email
		        SignIn user = signInServiceImpl.findByEmail(signIn.getEmail());

		  
		        if (user != null && signIn.getPassword().equals(user.getPassword())) {
		           
		            session.setAttribute("loggedInUser", signIn.getEmail());
		            return ResponseEntity.ok("Login successful");
		        } else {
		          
		            return ResponseEntity.badRequest().body("Invalid credentials");
		        }
		    } else {
		      
		        return ResponseEntity.badRequest().body("Invalid credentials");
		    }
	}
	
	
	@PostMapping("/reset-password")
    public ResponseEntity<String> resetPassword(@RequestBody SignIn signIn) {
		
        String email = signIn.getEmail();
        String newPassword = signIn.getNewPassword();

        SignIn user = signInServiceImpl.findByEmail(email);

        if (user != null) {
            signInServiceImpl.updatePassword(user, newPassword);
            return ResponseEntity.ok("Password reset successful");
        } else {
            return ResponseEntity.badRequest().body("User not found with the given email");
        }
	}
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	

