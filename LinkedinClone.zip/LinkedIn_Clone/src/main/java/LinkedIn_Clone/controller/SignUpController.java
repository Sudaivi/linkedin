package LinkedIn_Clone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import LinkedIn_Clone.entites.SignUp;
import LinkedIn_Clone.response.ApiRespones;
import LinkedIn_Clone.serviceImpl.SignUpServiceImpl;

@RestController
@RequestMapping("/api")
public class SignUpController {
	
	 @Autowired
	 private SignUpServiceImpl signUpServiceImpl;
	 
	   @PostMapping("/signup")
	    public ResponseEntity<String> registerUser(@RequestBody SignUp signup) {
		   
	        // Check if the email is already taken
	        if (signUpServiceImpl.findByEmail(signup.getEmail()) != null) {
	            return ResponseEntity.badRequest().body("email is already taken.");
	        }
	        signUpServiceImpl.registerUser(signup);
	        return ResponseEntity.ok("Signup successful.");
	        
	    }

	   @GetMapping("/findByEmail")
	    public ResponseEntity<Object> findByEmail(@RequestParam String email) {
	        String message;
	        SignUp user = signUpServiceImpl.findByEmail(email);

	        if (user != null) {
	            message = "User found with email: " + email;
	            return ResponseEntity.ok().body(new ApiRespones(true, user, message));
	        } else {
	            message = "User not found with email: " + email;
	            return ResponseEntity.status(404).body(new ApiRespones(false, null, message));
	        }
	    }
}
