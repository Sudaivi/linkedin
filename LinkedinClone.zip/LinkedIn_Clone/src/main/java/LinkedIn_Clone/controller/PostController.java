package LinkedIn_Clone.controller;

import java.util.List;
import org.omg.CORBA.UserException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import LinkedIn_Clone.dto.PostDto;
import LinkedIn_Clone.entites.Post;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.PostException;
import LinkedIn_Clone.mapper.PostDtoMapper;
import LinkedIn_Clone.repositories.UserRepository;
import LinkedIn_Clone.request.PostReplyRequest;
import LinkedIn_Clone.response.ApiResponse;
import LinkedIn_Clone.service.PostServices;
import LinkedIn_Clone.service.UserService;

@RestController
@RequestMapping("/api/post")
public class PostController {
	
	@Autowired
	private PostServices postService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserRepository userRepository;

	
	@PostMapping("/create")
    public ResponseEntity<PostDto> createPost(@RequestBody Post req, String email)throws UserException {
		User user = userRepository.findByEmail(email);
		Post post = postService.createPost(req, user);
		PostDto postDto = PostDtoMapper.toPostDto(post, user);
		return new ResponseEntity<>(postDto,HttpStatus.CREATED);
    }
	
	@PostMapping("/replyPost")
	public ResponseEntity<PostDto>  replyPost(@RequestBody PostReplyRequest req, String email)throws PostException {
		User user = userRepository.findByEmail(email);
		Post post = postService.createReply(req, user);
		PostDto postDto = PostDtoMapper.toPostDto(post, user);
		return new ResponseEntity<>(postDto,HttpStatus.CREATED);
	}
	
	@GetMapping("{postId}")
	public ResponseEntity <PostDto> getPostById(@PathVariable Long postId, String email) throws PostException{
		User user = userRepository.findByEmail(email);
		Post post = postService.findPostById(postId);
		PostDto postDto = PostDtoMapper.toPostDto(post, user);
		return new ResponseEntity<>(postDto,HttpStatus.CREATED);
	}
	
	
	@DeleteMapping("{postId}")
	public ResponseEntity<ApiResponse> deletePost(@PathVariable Long postId, String email) throws PostException, UserException {
	    try {
	        User user = userRepository.findByEmail(email);
	        if (user == null) {
	            throw new PostException("User not found with email: " + email);
	        }

	        postService.deletPostById(postId, user.getId());
	        ApiResponse apiResponse = new ApiResponse("Post deleted successfully", true);
	        return new ResponseEntity<>(apiResponse, HttpStatus.OK);
	    } catch (PostException | UserException e) {
	        return new ResponseEntity<>(new ApiResponse(e.getMessage(), false), HttpStatus.BAD_REQUEST);
	    }
	}

	
	@GetMapping("/post")
	public ResponseEntity <List<Post>> getAllPost() {
		List <Post> post = postService.findAllPost();
		return new ResponseEntity<>(post,HttpStatus.CREATED);
	}
	
	@GetMapping("/user/{userId}")
	public ResponseEntity <List<PostDto>> getUserPost(@PathVariable Long userId, String email) {

		User user = userRepository.findByEmail(email);
		List <Post> post = postService.getUserPost(user);
		List<PostDto> postDtos = PostDtoMapper.toPostDtos(post, user);
		return new ResponseEntity<>(postDtos,HttpStatus.CREATED);
	}
	
	@GetMapping("/user/{userId}/likes")
	public ResponseEntity <List<PostDto>> getByUserLikes(@PathVariable Long userId, String email) {
		User user = userRepository.findByEmail(email);
		List <Post> post = postService.findByLikesContainUser(user);
		List<PostDto> postDtos = PostDtoMapper.toPostDtos(post, user);
		return new ResponseEntity<>(postDtos,HttpStatus.CREATED);
	}
	
		
	
}
