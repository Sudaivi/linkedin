package LinkedIn_Clone.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import LinkedIn_Clone.dto.CurrentPositionDto;
import LinkedIn_Clone.exception.DuplicateUserException;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.response.ApiResponse;
import LinkedIn_Clone.serviceImpl.CurrentPositionServiceImpl;

@RestController
@RequestMapping("/api/currentpositions")
public class WorkExprienceController {
	
	@Autowired
    private CurrentPositionServiceImpl currentPositionService;

    @PostMapping("/add")
    public ResponseEntity<?> addCurrentPosition(@RequestBody CurrentPositionDto currentPositionDto) {
        try {
            CurrentPositionDto createdCurrentPositionDto = currentPositionService.addCurrentPosition(currentPositionDto);
            return new ResponseEntity<>(createdCurrentPositionDto, HttpStatus.CREATED);
        } catch (DuplicateUserException e) {
	        ApiResponse errorResponse = new ApiResponse(e.getMessage(), false);
	        return new ResponseEntity<>(errorResponse, HttpStatus.CONFLICT);
	    }
    }
    

    @GetMapping("/{currentPositionId}")
    public ResponseEntity<CurrentPositionDto> getCurrentPositionById(@PathVariable Long currentPositionId) {
        try {
            CurrentPositionDto currentPositionDto = currentPositionService.getCurrentPositionById(currentPositionId);
            return new ResponseEntity<>(currentPositionDto, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{currentPositionId}")
    public ResponseEntity<CurrentPositionDto> updateCurrentPosition(
            @RequestBody CurrentPositionDto currentPositionDto,
            @PathVariable Long currentPositionId) {
        try {
            CurrentPositionDto updatedCurrentPositionDto = currentPositionService.updateCurrentPosition(
                    currentPositionDto, currentPositionId);
            return new ResponseEntity<>(updatedCurrentPositionDto, HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/delete/{currentPositionId}")
    public ResponseEntity<Void> deleteCurrentPosition(@PathVariable Long currentPositionId) {
        try {
            currentPositionService.deleteCurrentPosition(currentPositionId);
            return new ResponseEntity<>(HttpStatus.OK);
        } catch (ResourceNotFoundException e) {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }
}


