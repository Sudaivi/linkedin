package LinkedIn_Clone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import LinkedIn_Clone.entites.Job;
import LinkedIn_Clone.exception.JobNotFoundException;
import LinkedIn_Clone.service.JobService;

@RestController
@RequestMapping("/api/job")
public class JobController {

	
	 @Autowired
	    private JobService jobService;

	    @PostMapping("/create")
	    public ResponseEntity<Job> createJob(@RequestBody Job job) {
	        Job createdJob = jobService.createJob(job);
	        return new ResponseEntity<>(createdJob, HttpStatus.CREATED);
	    }

	    @GetMapping("/all")
	    public ResponseEntity<List<Job>> getAllJobs() {
	        List<Job> jobs = jobService.getAllJobs();
	        return new ResponseEntity<>(jobs, HttpStatus.OK);
	    }

	    @GetMapping("/search")
	    public ResponseEntity<List<Job>> searchJobs(
	            @RequestParam(required = false) String location,
	            @RequestParam(required = false) String industry
	    ) {
	        List<Job> jobs = jobService.searchJobs(location, industry);
	        return new ResponseEntity<>(jobs, HttpStatus.OK);
	    }

	    @GetMapping("/{jobId}")
	    public ResponseEntity<Job> getJobDetails(@PathVariable Long jobId) throws JobNotFoundException {
	        Job job = jobService.getJobDetails(jobId);
	        if (job != null) {
	            return new ResponseEntity<>(job, HttpStatus.OK);
	        } else {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }
	    
	    @PutMapping("/update/{jobId}")
	    public ResponseEntity<String> updateJob(@PathVariable Long jobId, @RequestBody Job updatedJob)throws JobNotFoundException {
	        try {
	            jobService.updateJob(jobId, updatedJob);
	            return new ResponseEntity<>("Job updated successfully", HttpStatus.OK);
	        } catch (JobNotFoundException e) {
	            return new ResponseEntity<>(e.getMessage(), HttpStatus.NOT_FOUND);
	        }
	    }
	    
	   @GetMapping("/saved")
	    public ResponseEntity<List<Job>> getSavedJobs() {
	        List<Job> savedJobs = jobService.getSavedJobs();
	        return new ResponseEntity<>(savedJobs, HttpStatus.OK);
	    }
	    
	}