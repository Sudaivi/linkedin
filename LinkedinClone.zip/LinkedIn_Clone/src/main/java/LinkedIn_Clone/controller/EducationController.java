package LinkedIn_Clone.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import LinkedIn_Clone.dto.EducationDto;
import LinkedIn_Clone.exception.ResourceNotFoundException;
import LinkedIn_Clone.serviceImpl.EducationServiceImpl;

@RestController
@RequestMapping("/api/educations")

public class EducationController {

	

	    @Autowired
	    private EducationServiceImpl educationService;

	    @PostMapping("/education")
	    public ResponseEntity<?> createEducation(@RequestBody EducationDto educationDto) {
	        try {
	            EducationDto createdEducationDto = educationService.createEducation(educationDto);
	            return new ResponseEntity<>(createdEducationDto, HttpStatus.CREATED);
	        } catch (Exception e) {
	            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
	        }
	    }

	    @PutMapping("/education/{educationId}")
	    public ResponseEntity<EducationDto> updateEducation(@RequestBody EducationDto educationDto,
	                                                       @PathVariable Long educationId) {
	        try {
	            EducationDto updatedEducationDto = educationService.updateEducation(educationDto, educationId);
	            return new ResponseEntity<>(updatedEducationDto, HttpStatus.OK);
	        } catch (ResourceNotFoundException e) {
	            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
	        }
	    }

	    @DeleteMapping("/education/{educationId}")
	    public ResponseEntity<?> deleteEducation(@PathVariable Long educationId) {
	        educationService.deleteEducation(educationId);
	        return new ResponseEntity<>(HttpStatus.OK);
	    }
	    
	    @GetMapping("{educationId}")
		public ResponseEntity <EducationDto>  getUserById(@PathVariable Long educationId){
	    	EducationDto getEducationById = this.educationService.getEducationById(educationId);
			return new ResponseEntity<>(getEducationById,HttpStatus.OK);
		}
	 
	    @GetMapping("/education")
	    public List<EducationDto> getEducationByUserId() {
	        
	        return this.educationService.getAllEducation();
	    }
	    
	  
	    
	    

		}
	


