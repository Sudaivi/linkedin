package LinkedIn_Clone.dto;

import java.time.LocalDateTime;
import java.util.List;
import lombok.Data;

@Data
public class PostDto {
	
	private Long id;
	private UserDto user;
	private String comment;
	private String image;
	private String video;
	private int totalLikes;
	private int totalReplies;
	private boolean isLiked;
	private LocalDateTime createdAt;
	private List<PostDto> replyPost;


}
