package LinkedIn_Clone.dto;



import LinkedIn_Clone.entites.User;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ConnectionDto {

	private Long id;

  
    private User user;

   
    private User connection;
    private Long userId;
}
