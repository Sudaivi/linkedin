package LinkedIn_Clone.dto;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import LinkedIn_Clone.entites.Connection;
import LinkedIn_Clone.entites.WorkExprience;
import LinkedIn_Clone.entites.Education;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;


@NoArgsConstructor
@Getter
@Setter
public class UserDto {
	
	private Long id;
	private String firstName;
	private String lastName;
	private String email;
	private String password;
	private Date dateOfBirth;
	private String location;
	private String image;
	private String mobile;
	private String backGroundImage;
	private String headline;
	private String skills;
	private String about;
	private boolean followed;
	
	private List<UserDto> followers = new ArrayList<>();
	private List<UserDto> following = new ArrayList<>();
	private List<Education> educations;
	private List<WorkExprience> currentPosition;
	private List<Connection> connections;
	
	
	
}
