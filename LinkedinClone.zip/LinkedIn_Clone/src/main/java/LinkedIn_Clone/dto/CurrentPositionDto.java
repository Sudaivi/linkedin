package LinkedIn_Clone.dto;

import java.util.Date;
import LinkedIn_Clone.entites.User;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class CurrentPositionDto {
	
	private Long id;

    private String title;
    private String employmentType;
    private String companyName;
    private String location;
    private String locationType;
    private Date startDate;
    private Date endDate;
    private String description;
    private String skills;
    private User user;
    private Long userId;
    
    

}
