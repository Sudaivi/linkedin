package LinkedIn_Clone.dto;

import java.time.LocalDate;
import LinkedIn_Clone.entites.User;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class EducationDto {

	private Long id;

    private String degree;
    private String school;
    private LocalDate startDate;
    private LocalDate endDate;
    private User user;
    private Long userId;
}
