package LinkedIn_Clone.service;

import java.util.List;

import LinkedIn_Clone.dto.EducationDto;


public interface EducationService {
	public EducationDto createEducation(EducationDto educationDto);
	public EducationDto updateEducation(EducationDto educationDto, Long educationId);
	public EducationDto getEducationById(Long educationId);
	public void deleteEducation(Long educationId);
	public List<EducationDto> getAllEducation();
}
