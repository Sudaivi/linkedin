package LinkedIn_Clone.service;

import java.util.List;

import LinkedIn_Clone.entites.FreeJobPost;

public interface FreeJobPostService {

	public FreeJobPost postFreeJob(FreeJobPost freeJobPost);
	public List<FreeJobPost> getAllFreeJobPosts();
	public FreeJobPost getFreeJobPostById(Long freeJobPostId);
	public void deleteFreeJobPost(Long freeJobPostId);
}
