package LinkedIn_Clone.service;

import LinkedIn_Clone.dto.CurrentPositionDto;

public interface CurrentPositionService {

	public CurrentPositionDto addCurrentPosition(CurrentPositionDto currentPositionDto);
	public CurrentPositionDto updateCurrentPosition(CurrentPositionDto currentPositionDto, Long currentPositionId);
	 public void deleteCurrentPosition(Long currentPositionId);
	 public CurrentPositionDto getCurrentPositionById(Long currentPositionId);
}
