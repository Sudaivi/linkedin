package LinkedIn_Clone.service;

import java.util.List;
import LinkedIn_Clone.dto.CurrentPositionDto;
import LinkedIn_Clone.dto.EducationDto;
import LinkedIn_Clone.dto.UserDto;
import LinkedIn_Clone.entites.User;


public interface UserService {
	
	
	//create
	UserDto createUser(UserDto userDto);
	
	//update
	UserDto updateUser(UserDto userDto,Long userId);
	
	//get
	UserDto getUserById(Long userId);
	
	//delete
	void deleteUser(Long userId);
	
	//getall
	List<UserDto> getAllUser();
	
	User followUser(User user,Long userId);
	
	public List<EducationDto> getUserEducations(Long userId);
	public List<CurrentPositionDto> getUserCurrentPositions(Long userId);
	

	



}
