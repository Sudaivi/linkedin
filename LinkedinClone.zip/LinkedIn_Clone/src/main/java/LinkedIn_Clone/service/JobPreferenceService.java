package LinkedIn_Clone.service;

import java.util.List;

import LinkedIn_Clone.entites.JobPreference;

public interface JobPreferenceService {

	public JobPreference createJobPreference(Long userId, Long jobId, JobPreference jobPreference);
	public List<JobPreference> getJobPreferencesForUser(Long userId);
	 public List<JobPreference> getJobPreferencesForJob(Long jobId);
	 public void deleteJobPreference(Long jobPreferenceId);
}
