package LinkedIn_Clone.service;

import LinkedIn_Clone.entites.SignUp;

public interface SignUpService {
	SignUp registerUser(SignUp signup);
	SignUp findByEmail(String email);

}
