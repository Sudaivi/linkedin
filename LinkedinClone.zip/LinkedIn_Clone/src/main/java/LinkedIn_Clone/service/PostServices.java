package LinkedIn_Clone.service;

import java.util.List;

import org.omg.CORBA.UserException;

import LinkedIn_Clone.entites.Post;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.PostException;
import LinkedIn_Clone.request.PostReplyRequest;

public interface PostServices {

	public Post createPost(Post req, User user)throws UserException;
	public List<Post> findAllPost();
	
	
	public void deletPostById(Long postId,Long userId)throws PostException, UserException;
	public Post createReply(PostReplyRequest req, User user)throws PostException;
	public List<Post> getUserPost(User user);
	public List<Post> findByLikesContainUser(User user);
	
	Post findPostById(Long postId) throws PostException;
	
	
}

