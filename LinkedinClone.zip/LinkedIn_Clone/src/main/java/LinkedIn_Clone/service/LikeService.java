package LinkedIn_Clone.service;

import java.util.List;

import org.omg.CORBA.UserException;

import LinkedIn_Clone.entites.Like;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.exception.PostException;

public interface LikeService {
	
	public Like likePost (Long postId, User user)throws PostException, UserException;
	public List <Like> getAllLikes (Long postId)throws PostException;
}
