package LinkedIn_Clone.service;

import java.util.List;
import LinkedIn_Clone.entites.Connection;
import LinkedIn_Clone.entites.User;

public interface ConnectionService {

	
	List<Connection> getPendingConnections(User receiver);
    void acceptConnection(Long connectionId);
    void rejectConnection(Long connectionId);
    Connection sendConnectionRequest(User sender, User receiver);
    public void removeConnection(Long connectionId);
    public List<Connection> getAllConnectedConnections(User user);
}
