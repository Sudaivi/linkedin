package LinkedIn_Clone.service;

import LinkedIn_Clone.entites.SignIn;

public interface SignInService {
	SignIn registerUser(SignIn signIn);
	SignIn findByEmail(String email);
	void updatePassword(SignIn signIn, String newPassword);

}
