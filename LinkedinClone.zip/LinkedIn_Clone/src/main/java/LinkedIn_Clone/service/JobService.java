package LinkedIn_Clone.service;

import java.util.List;

import LinkedIn_Clone.entites.Job;
import LinkedIn_Clone.exception.JobNotFoundException;



public interface JobService {

	public Job createJob(Job job);
	public List<Job> getAllJobs(); 
	public List<Job> searchJobs(String location, String industry);
	public Job getJobDetails(Long jobId)throws JobNotFoundException;
	 public Job updateJob(Long jobId, Job updatedJob)throws JobNotFoundException ;
	 public List<Job> getSavedJobs();
}
