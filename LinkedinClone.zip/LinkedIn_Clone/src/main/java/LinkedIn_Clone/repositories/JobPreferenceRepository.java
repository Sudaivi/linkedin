package LinkedIn_Clone.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import LinkedIn_Clone.entites.JobPreference;


public interface JobPreferenceRepository extends JpaRepository<JobPreference, Long>{

	  @Query("SELECT jp FROM JobPreference jp WHERE jp.user.id = :userId")
	    List<JobPreference> findByUserId(@Param("userId") Long userId);

	    @Query("SELECT jp FROM JobPreference jp WHERE jp.job.id = :jobId")
	    List<JobPreference> findByJobId(@Param("jobId") Long jobId);
}
