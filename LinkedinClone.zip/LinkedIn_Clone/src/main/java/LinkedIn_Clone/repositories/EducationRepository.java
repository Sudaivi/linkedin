package LinkedIn_Clone.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import LinkedIn_Clone.entites.Education;


public interface EducationRepository extends JpaRepository<Education, Long> {

	List<Education> findByUserId(Long userId);
	
}
