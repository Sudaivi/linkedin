package LinkedIn_Clone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import LinkedIn_Clone.entites.SignUp;

public interface SignUpRepository extends JpaRepository<SignUp, Integer> {
	SignUp findByEmail(String email);

}
