package LinkedIn_Clone.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import LinkedIn_Clone.entites.Connection;
import LinkedIn_Clone.entites.ConnectionStatus;
import LinkedIn_Clone.entites.User;

public interface ConnectionRepository extends JpaRepository<Connection, Long> {
	 List<Connection> findByReceiverAndStatus(User receiver, ConnectionStatus status);

	List<Connection> findBySenderAndStatusOrReceiverAndStatus(User sender, ConnectionStatus senderStatus, User receiver, ConnectionStatus receiverStatus);
}
