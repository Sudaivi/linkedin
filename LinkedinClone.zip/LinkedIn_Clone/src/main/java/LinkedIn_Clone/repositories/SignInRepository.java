package LinkedIn_Clone.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import LinkedIn_Clone.entites.SignIn;


public interface SignInRepository extends JpaRepository<SignIn, Integer> {
	SignIn findByEmail(String email);
}
