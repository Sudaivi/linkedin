package LinkedIn_Clone.repositories;


import org.springframework.data.jpa.repository.JpaRepository;

import LinkedIn_Clone.entites.User;

public interface UserRepository extends JpaRepository<User, Long> {
	
	public User findByEmail(String email);
	public User findByMobile(String mobile);
	public User getUserById(User user);



}
