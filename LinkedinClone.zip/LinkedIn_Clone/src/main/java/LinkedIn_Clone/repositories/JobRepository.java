package LinkedIn_Clone.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import LinkedIn_Clone.entites.Job;

public interface JobRepository extends JpaRepository<Job, Long> {
	List<Job> findByLocationAndIndustry(String location, String industry);
	 List<Job> findByIsSaved(boolean isSaved);
	List<Job> findByLocation(String location);
	List<Job> findByIndustry(String industry);
}
