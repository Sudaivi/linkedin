package LinkedIn_Clone.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import LinkedIn_Clone.entites.Post;
import LinkedIn_Clone.entites.User;

public interface PostRepository extends JpaRepository<Post, Long> {
	

    List<Post> findAllByIsPostOrderByCreatedAtDesc(boolean isPost);

	 List<Post> findByUserAndIsPostOrderByCreatedAtDesc(User user, boolean isPost);

	    List<Post> findByLikeContainingOrderByCreatedAtDesc(User user);

	    @Query("SELECT p FROM Post p JOIN p.like l WHERE l.user.id = :userId")
	    List<Post> findByLikesUserId(Long userId);


	

}
