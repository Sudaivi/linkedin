package LinkedIn_Clone.util;

import LinkedIn_Clone.entites.Like;
import LinkedIn_Clone.entites.Post;
import LinkedIn_Clone.entites.User;

public class PostUtil {

	public static final boolean isLikeByReqUser(User reqUser, Post post) {
		for(Like like : post.getLike()) {
			if(like.getUser().getId().equals(reqUser.getId())) {
				return true;
			}
			
		}
		return false;
	}
}
