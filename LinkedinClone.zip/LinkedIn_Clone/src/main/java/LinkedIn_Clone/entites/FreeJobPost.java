package LinkedIn_Clone.entites;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name="free_job_post")
@NoArgsConstructor
@Getter
@Setter
public class FreeJobPost {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	    private Long id;

	    private String jobTitle;
	    private String company;
	    private String workplace;
	    private String jobLocation;
	    private String jobType;
}
