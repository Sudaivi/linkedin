package LinkedIn_Clone.entites;

public enum ConnectionStatus {

	PENDING, ACCEPTED, REJECTED
}
