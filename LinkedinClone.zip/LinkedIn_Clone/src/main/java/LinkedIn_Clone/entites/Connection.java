package LinkedIn_Clone.entites;



import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import lombok.Getter;
import lombok.Setter;


@Entity
@Table(name="connection")
@Getter
@Setter
public class Connection {
	

@Id
@GeneratedValue(strategy = GenerationType.IDENTITY)

private Long id;

@ManyToOne
@JoinColumn(name = "sender_id")
private User sender;

@ManyToOne
@JoinColumn(name = "receiver_id")
private User receiver;

@Enumerated(EnumType.STRING)
private ConnectionStatus status;

}
