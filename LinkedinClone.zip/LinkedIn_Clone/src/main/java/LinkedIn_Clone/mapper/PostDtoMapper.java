package LinkedIn_Clone.mapper;

import java.util.ArrayList;
import java.util.List;

import LinkedIn_Clone.dto.PostDto;
import LinkedIn_Clone.dto.UserDto;
import LinkedIn_Clone.entites.Post;
import LinkedIn_Clone.entites.User;
import LinkedIn_Clone.util.PostUtil;

public class PostDtoMapper {
	public static PostDto toPostDto(Post post,User reqUser) {
		UserDto user = UserDtoMapper.toUserDto(post.getUser());
		boolean isLiked = PostUtil.isLikeByReqUser(reqUser,post);
		
		PostDto postDto = new PostDto();
		postDto.setId(post.getId());
		postDto.setComment(post.getComment());
		postDto.setCreatedAt(post.getCreatedAt());
		postDto.setImage(post.getImage());
		postDto.setTotalLikes(post.getLike().size());
		postDto.setTotalReplies(post.getReplyPost().size());
		postDto.setUser(user);
		postDto.setLiked(isLiked);
		postDto.setReplyPost(toPostDtos(post.getReplyPost(),reqUser));
		postDto.setVideo(post.getVideo());
		return postDto;
	}
	
	public static List<PostDto> toPostDtos(List<Post> posts, User reqUser){
		List<PostDto> postDtos = new ArrayList<>();
		
		for(Post post : posts) {
			PostDto postdto = toReplyPostDto(post,reqUser);
			postDtos.add(postdto);
		}
		return postDtos;
	}

	private static PostDto toReplyPostDto(Post post, User reqUser) {
		
			UserDto user = UserDtoMapper.toUserDto(post.getUser());
			boolean isLiked = PostUtil.isLikeByReqUser(reqUser,post);
			
			PostDto postDto = new PostDto();
			postDto.setId(post.getId());
			postDto.setComment(post.getComment());
			postDto.setCreatedAt(post.getCreatedAt());
			postDto.setImage(post.getImage());
			postDto.setTotalLikes(post.getLike().size());
			postDto.setTotalReplies(post.getReplyPost().size());
			postDto.setUser(user);
			postDto.setLiked(isLiked);
			postDto.setVideo(post.getVideo());
			return postDto;
		}
	

}
