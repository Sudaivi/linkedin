package LinkedIn_Clone.mapper;

import java.util.ArrayList;
import java.util.List;
import LinkedIn_Clone.dto.UserDto;
import LinkedIn_Clone.entites.User;

public class UserDtoMapper {
	
	
	
	//converting user To UserDto
	public static UserDto toUserDto (User user) {
		UserDto userDto = new UserDto();
		userDto.setId(user.getId());
		userDto.setEmail(user.getEmail());
		userDto.setFirstName(user.getFirstName());
		userDto.setLastName(user.getLastName());
		userDto.setImage(user.getImage());
		userDto.setBackGroundImage(user.getBackGroundImage());
		userDto.setDateOfBirth(user.getDateOfBirth());
		userDto.setFollowers(toUserDtos(user.getFollowers()));
		userDto.setFollowing(toUserDtos(user.getFollowing()));
		userDto.setLocation(user.getLocation());
		userDto.setHeadline(user.getHeadline());
		userDto.setSkills(user.getSkills());
		userDto.setEducations(user.getEducations());
	
		
		return userDto;
	}
	
	public static List<UserDto> toUserDtos (List<User> followers){
		List <UserDto> userDtos = new ArrayList<>();
		
		for(User user : followers) {
			UserDto userDto = new UserDto();
			userDto.setId(user.getId());
			userDto.setEmail(user.getEmail());
			userDto.setFirstName(user.getFirstName());
			userDto.setImage(user.getImage());
			userDtos.add(userDto);
			
			
		}
		
		return userDtos;
	}




}
